# FATEC_DES_WEB_2_2022_Avaliacao1
Avaliação Desenvolvimento WEB II

Daniel de Godoy Carolino

Usuário: fatec
Senha: araras

*Página index - Foi criado uma página com login e senha, com checagem;
*Página inico - Depois que fez abertudo do cadastro é apresentado o menu;
*Página cadastro - Onde é feito o cadastro, que será enviado para um .txt;
*Página logout  - é feita a saida do sistema.
*registro.txt é onde é salvo os registros do cadastro.


